package inventory.dao;

public interface RoleDAO<E> extends BaseDAO<E> {

}
