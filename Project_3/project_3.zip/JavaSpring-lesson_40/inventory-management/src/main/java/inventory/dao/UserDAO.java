package inventory.dao;

public interface UserDAO<E> extends BaseDAO<E> {

}
