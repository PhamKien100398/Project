package inventory.dao;

public interface CategoryDAO<E> extends BaseDAO<E> {

}
