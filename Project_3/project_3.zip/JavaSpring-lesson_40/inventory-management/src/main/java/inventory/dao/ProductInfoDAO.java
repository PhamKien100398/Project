package inventory.dao;

public interface ProductInfoDAO<E> extends BaseDAO<E> {

}
