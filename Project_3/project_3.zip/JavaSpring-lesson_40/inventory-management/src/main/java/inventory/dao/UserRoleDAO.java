package inventory.dao;

public interface UserRoleDAO<E> extends BaseDAO<E> {

}
