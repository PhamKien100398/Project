package inventory.dao;

public interface MenuDAO<E> extends BaseDAO<E> {

}
