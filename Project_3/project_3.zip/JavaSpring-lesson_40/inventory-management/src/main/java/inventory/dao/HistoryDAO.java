package inventory.dao;

public interface HistoryDAO<E> extends BaseDAO<E> {

}
