package inventory.dao;

public interface InvoiceDAO<E> extends BaseDAO<E> {

}
