package inventory.dao;

public interface ProductInStockDAO<E> extends BaseDAO<E> {

}
